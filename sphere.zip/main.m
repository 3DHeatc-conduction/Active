load matlab.mat

tic;
for i=3004:6000
    disp(i);
    num=num2str(i);
    
    gsa;
    m=floor((i-3001)/1000)+1;
    km=[0.08 25.3 8000];
    k=km(m);
    
    pram=[xa ya za r xs ys zs ls ws hs k];
    
    path=['H:\Heat_conduction\inner\sphere\data\' num '.csv'];
    model(pram,path);
    disp('Calculation ends.')
    genk;
    readcsvdata;
    path3=['H:\Heat_conduction\inner\sphere\h5\' num '.h5'];
    h5create(path3,'/alpha',[32 32 32]);
    h5write(path3,'/alpha',kmat);
    
    h5create(path3,'/T',[32 32 32]);
    h5write(path3,'/T',temp);
end
toc;