

    
    k=zeros(32768,1);
    for j=1:32768
        p1=((xyz(j,1)-xa)^2+(xyz(j,2)-ya)^2+(xyz(j,3)-za)^2<=r^2);
        p2=((xyz(j,1)>=xs)&&(xyz(j,1)<=xs+ls)&&(xyz(j,2)>=ys)&&(xyz(j,2)<=ys+ws)&&(xyz(j,3)>=zs)&&(xyz(j,3)<=zs+hs));
        if (p1)
            k(j)=m;
        end
        if (p2)
            k(j)=10;
        end
    end
    kmat=reshape(k,32,32,32);
    path1=['H:\Heat_conduction\inner\sphere\input\' num '.mat'];
    save(path1,'kmat');
