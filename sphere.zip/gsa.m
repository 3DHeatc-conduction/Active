while(1)
    xa=randi([12,20])*0.1;
    ya=randi([12,20])*0.1;
    za=randi([12,20])*0.1;
    
    r=randi([6,11])*0.1;
    

    
    xs=randi(15)*0.1;
    ys=randi(15)*0.1;
    zs=randi(15)*0.1;
    
    ls=randi([2,4])*0.1;
    ws=randi([2,4])*0.1;
    hs=randi([2,4])*0.1;
    
    x1=xs+ls/2;
    y1=ys+ws/2;
    z1=zs+hs/2;
    
    d=sqrt((xa-x1)^2+(ya-y1)^2+(za-z1)^2);
    if (d>r+sqrt(ls^2+ws^2+hs^2)/2)
        break
    end
end