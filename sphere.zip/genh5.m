for i=232:4000
    index=num2str(i);
    
    path1=['H:\Heat_conduction\H0917\input\' index '.mat'];
    path2=['H:\Heat_conduction\H0917\mat\' index '.mat'];
    load(path1);
    load(path2);
    path3=['H:\Heat_conduction\H0917\h5\' index '.h5'];
    h5create(path3,'/alpha',[32 32 32]);
    h5write(path3,'/alpha',kmat);
    
    h5create(path3,'/T',[32 32 32]);
    h5write(path3,'/T',temp);
    
end