

    
    k=zeros(32768,1);
    for j=1:32768
        p1=((xyz(j,1)>=xa)&&(xyz(j,1)<=xa+la)&&(xyz(j,2)>=ya)&&(xyz(j,2)<=ya+wa)&&(xyz(j,3)>=za)&&(xyz(j,3)<=za+ha));
        p2=((xyz(j,1)>=xs)&&(xyz(j,1)<=xs+ls)&&(xyz(j,2)>=ys)&&(xyz(j,2)<=ys+ws)&&(xyz(j,3)>=zs)&&(xyz(j,3)<=zs+hs));
        if (p1)
            k(j)=3;
        end
        if (p2)
            k(j)=10;
        end
    end
    kmat=reshape(k,32,32,32);
    path1=['H:\Heat_conduction\inner\cuboid\k008\input\' num '.mat'];
    save(path1,'kmat');
