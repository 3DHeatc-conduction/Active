load matlab.mat

tic;
for i=2001:3000
    disp(i);
    num=num2str(i);
    
    gsa;
    
    pram=[xa ya za la wa ha xs ys zs ls ws hs];
    
    path=['H:\Heat_conduction\inner\cuboid\k008\data\' num '.csv'];
    model(pram,path);
    disp('Calculation ends.')
    genk;
    readcsvdata;
    path3=['H:\Heat_conduction\inner\cuboid\k008\h5\' num '.h5'];
    h5create(path3,'/alpha',[32 32 32]);
    h5write(path3,'/alpha',kmat);
    
    h5create(path3,'/T',[32 32 32]);
    h5write(path3,'/T',temp);
end
toc;