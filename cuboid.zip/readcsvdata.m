
   
    path=['H:\Heat_conduction\inner\cuboid\k008\data\' num '.csv'];
    temp = csvread(path, 9, 3);
    temp=reshape(temp,32,32,32);
    path1=['H:\Heat_conduction\inner\cuboid\k008\mat\' num '.mat'];
    save(path1,'temp');


