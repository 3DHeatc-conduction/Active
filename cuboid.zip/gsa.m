while(1)
    xa=randi(15)*0.1;
    ya=randi(15)*0.1;
    za=randi(15)*0.1;
    
    la=randi([4,16])*0.1;
    wa=randi([4,16])*0.1;
    ha=randi([4,16])*0.1;
    
    x0=xa+la/2;
    y0=ya+wa/2;
    z0=za+ha/2;
    
    xs=randi(15)*0.1;
    ys=randi(15)*0.1;
    zs=randi(15)*0.1;
    
    ls=randi([2,4])*0.1;
    ws=randi([2,4])*0.1;
    hs=randi([2,4])*0.1;
    
    x1=xs+ls/2;
    y1=ys+ws/2;
    z1=zs+hs/2;
    
    d=sqrt((x0-x1)^2+(y0-y1)^2+(z0-z1)^2);
    if (d>sqrt(la^2+wa^2+ha^2)/2+sqrt(ls^2+ws^2+hs^2)/2)
        break
    end
end
    