while(1)
    xa=randi([12,20])*0.1;
    ya=randi([12,20])*0.1;
    za=randi([12,20])*0.1;
    
    r1=randi([6,11])*0.1;
    r2=randi([6,11])*0.1;
    h=randi([6,11])*0.1;

    
    xs=randi(15)*0.1;
    ys=randi(15)*0.1;
    zs=randi(15)*0.1;
    
    ls=randi([2,4])*0.1;
    ws=randi([2,4])*0.1;
    hs=randi([2,4])*0.1;
    
    x1=xs+ls/2;
    y1=ys+ws/2;
    z1=zs+hs/2;
    
    d=sqrt((xa-x1)^2+(ya-y1)^2+(za+h/2-z1)^2);
    d1=sqrt(r1^2+(h/2)^2)+sqrt(ls^2+ws^2+hs^2)/2;
    d2=sqrt(r2^2+(h/2)^2)+sqrt(ls^2+ws^2+hs^2)/2;
    
    if ((d>d1)&&(d>d2))
        break
    end
end