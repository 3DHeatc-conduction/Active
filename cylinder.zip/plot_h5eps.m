function  plot_h5eps(eps)
scatter_eps=eps;

Nx=32;
Ny=32;
Nz=32;
xs=1:Nx;
ys=1:Ny;
zs=1:Nz;



for ii=1:Nx
    for jj=1:Ny
        for kk=1:Nz
            if(scatter_eps(ii,jj,kk)==0)
                scatter_eps(ii,jj,kk)=NaN;
            end
        end
    end
end
[x,y,z]=meshgrid(1:Nx,1:Ny,1:Nz);
figure;
set(groot,'defaultLineLineWidth',1.5)
h=slice(x,y,z,scatter_eps,xs,ys,zs);
% set(groot,'defaultLineLineWidth',1.5)
set(h,'FaceColor','interp','EdgeColor','none');
set(gca,'FontSize',30,'LineWidth',1.5);
camproj perspective
%colorbar;
caxis([0,5]);


set(gca,'FontSize',24);
set(gca,'xtick',[],'ytick',[],'ztick',[])
axis square

xlabel('x');
ylabel('y');
zlabel('z');
end


